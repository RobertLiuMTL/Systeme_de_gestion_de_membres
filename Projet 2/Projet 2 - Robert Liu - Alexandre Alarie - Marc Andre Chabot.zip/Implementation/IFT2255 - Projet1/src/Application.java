import java.util.Scanner;

/**
 *La Classe main sert uniquement à démarrer le logiciel
 *
 */
public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataCenter data = new DataCenter();
	}
}