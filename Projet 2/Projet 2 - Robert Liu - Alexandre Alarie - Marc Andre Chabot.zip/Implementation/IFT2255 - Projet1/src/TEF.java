
public class TEF {
	String nomDuPro;
	Service service;
	int numeroPro;
	int nombreInscrit;
	
	public TEF(String pro, Service service,int  numeroPro,int nombreInscrit) {
		this.nomDuPro= pro;
		this.service = service;
		this.numeroPro = numeroPro;
		this.nombreInscrit= nombreInscrit;
	}
	//methode qui reste a completer
	public String representationTEF() {
		String representation = "";
		
		
		return representation;
	}
	
}
